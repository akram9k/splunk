Splunk Add-on for Microsoft Windows version 4.8.4
Copyright (C) 2009-2016 Splunk Inc. All Rights Reserved.

For documentation, see: http://docs.splunk.com/Documentation/WindowsAddOn/latest
